use super::*;

#[test]
fn test_send_tokens() {
    let mut wallet = Wallet::new();
    wallet.receive_tokens("alice".to_string(), 100);
    assert_eq!(wallet.send_tokens("alice".to_string(), "bob".to_string(), 50), Ok(()));
    assert_eq!(wallet.get_balance("alice".to_string()), 50);
    assert_eq!(wallet.get_balance("bob".to_string()), 50);
}

#[test]
fn test_insufficient_balance() {
    let mut wallet = Wallet::new();
    wallet.receive_tokens("alice".to_string(), 100);
    assert_eq!(wallet.send_tokens("alice".to_string(), "bob".to_string(), 150), Err("Insufficient balance".to_string()));
}

#[test]
fn test_receive_tokens() {
    let mut wallet = Wallet::new();
    wallet.receive_tokens("alice".to_string(), 100);
    assert_eq!(wallet.get_balance("alice".to_string()), 100);
}