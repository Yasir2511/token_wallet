use ic_cdk::export::candid::CandidType;
use ic_cdk::storage;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(CandidType, Serialize, Deserialize)]
struct Wallet {
    balances: HashMap<String, u64>,
}

impl Wallet {
    fn new() -> Self {
        Wallet {
            balances: HashMap::new(),
        }
    }

    fn send_tokens(&mut self, from: String, to: String, amount: u64) -> Result<(), String> {
        let from_balance = self.balances.get_mut(&from).ok_or("Sender not found")?;
        if *from_balance < amount {
            return Err("Insufficient balance".to_string());
        }
        *from_balance -= amount;
        *self.balances.entry(to).or_insert(0) += amount;
        Ok(())
    }

    fn receive_tokens(&mut self, address: String, amount: u64) {
        *self.balances.entry(address).or_insert(0) += amount;
    }

    fn get_balance(&self, address: String) -> u64 {
        *self.balances.get(&address).unwrap_or(&0)
    }
}

static mut WALLET: Option<Wallet> = None;

#[ic_cdk::update]
fn send(from: String, to: String, amount: u64) -> Result<(), String> {
    unsafe { WALLET.as_mut().unwrap().send_tokens(from, to, amount) }
}

#[ic_cdk::update]
fn receive(address: String, amount: u64) {
    unsafe { WALLET.as_mut().unwrap().receive_tokens(address, amount) }
}

#[ic_cdk::query]
fn get_balance(address: String) -> u64 {
    unsafe { WALLET.as_mut().unwrap().get_balance(address) }
}

#[ic_cdk::init]
fn init() {
    unsafe { WALLET = Some(Wallet::new()) };
}