# Token Wallet on ICP Blockchain

## Overview
This project is a secure token wallet built on the Internet Computer Protocol (ICP) blockchain using Rust. It supports sending and receiving tokens, as well as checking balances.

## Setup
1. Install Rust and DFX.
2. Clone this repository.
3. Run `dfx deploy` to deploy the canister.

## Usage
- Send tokens: `dfx canister call token_wallet_backend send '("alice", "bob", 100)'`
- Receive tokens: `dfx canister call token_wallet_backend receive '("alice", 100)'`
- Check balance: `dfx canister call token_wallet_backend get_balance '("alice")'`

## Testing
Run `cargo test` to execute unit tests.

## License
This project is licensed under the MIT License.